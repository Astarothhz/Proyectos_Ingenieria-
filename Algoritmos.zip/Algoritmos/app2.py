# Clave fija
KEY = "clave123"

# Función para obtener desplazamientos de la clave
def obtener_desplazamientos(clave):
    return [ord(c) % 26 for c in clave if c.isalnum()]

# Función de encriptación
def encriptar(texto):
    desplazamientos = obtener_desplazamientos(KEY)
    encriptado = ""
    print("\nProceso de encriptación:")
    
    for i, caracter in enumerate(texto):
        if 'a' <= caracter <= 'z':  # Letras minúsculas
            nuevo_caracter = chr((ord(caracter) - ord('a') + desplazamientos[i % len(desplazamientos)]) % 26 + ord('a'))
        elif 'A' <= caracter <= 'Z':  # Letras mayúsculas
            nuevo_caracter = chr((ord(caracter) - ord('A') + desplazamientos[i % len(desplazamientos)]) % 26 + ord('A'))
        elif '0' <= caracter <= '9':  # Dígitos numéricos
            nuevo_caracter = chr((ord(caracter) - ord('0') + desplazamientos[i % len(desplazamientos)]) % 10 + ord('0'))
        else:
            print("Error: El texto contiene caracteres inválidos.")
            return None
        
        encriptado += nuevo_caracter
        print(f"Carácter original: {caracter} -> Carácter encriptado: {nuevo_caracter}")
    
    return encriptado

# Función de desencriptación
def desencriptar(texto):
    desplazamientos = obtener_desplazamientos(KEY)
    desencriptado = ""
    print("\nProceso de desencriptación:")
    
    for i, caracter in enumerate(texto):
        if 'a' <= caracter <= 'z':  # Letras minúsculas
            nuevo_caracter = chr((ord(caracter) - ord('a') - desplazamientos[i % len(desplazamientos)]) % 26 + ord('a'))
        elif 'A' <= caracter <= 'Z':  # Letras mayúsculas
            nuevo_caracter = chr((ord(caracter) - ord('A') - desplazamientos[i % len(desplazamientos)]) % 26 + ord('A'))
        elif '0' <= caracter <= '9':  # Dígitos numéricos
            nuevo_caracter = chr((ord(caracter) - ord('0') - desplazamientos[i % len(desplazamientos)]) % 10 + ord('0'))
        else:
            print("Error: El texto contiene caracteres inválidos.")
            return None
        
        desencriptado += nuevo_caracter
        print(f"Carácter encriptado: {caracter} -> Carácter desencriptado: {nuevo_caracter}")
    
    return desencriptado

# Menú principal
def menu():
    while True:
        print("\n--- Menú ---")
        print("1. Encriptar una palabra")
        print("2. Desencriptar una palabra")
        print("3. Salir")
        
        opcion = input("Seleccione una opción: ")
        
        if opcion == "1":
            palabra = input("Ingrese la palabra o número a encriptar: ")
            texto_encriptado = encriptar(palabra)
            if texto_encriptado:
                print(f"\nTexto encriptado: {texto_encriptado}")
        elif opcion == "2":
            palabra = input("Ingrese la palabra o número a desencriptar: ")
            texto_desencriptado = desencriptar(palabra)
            if texto_desencriptado:
                print(f"\nTexto desencriptado: {texto_desencriptado}")
        elif opcion == "3":
            print("Saliendo del programa.")
            break
        else:
            print("Opción no válida. Intente de nuevo.")

# Ejecución del programa
menu()
