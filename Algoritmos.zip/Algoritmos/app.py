# Conjunto de caracteres para el encriptado y desencriptado
conjunto_caracteres = (
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ¡!#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
)

# Definir una clave secreta fija
CLAVE_SECRETA = "mi_clave_secreta"

# Función para encriptar una palabra
def encriptar_palabra_compleja(palabra):
    # Paso 1: Invertir la palabra
    palabra_invertida = palabra[::-1]
    
    # Paso 2: Crear una clave numérica basada en la clave secreta
    claves_numericas = [
        conjunto_caracteres.index(letra)
        for letra in CLAVE_SECRETA
        if letra in conjunto_caracteres
    ]
    
    # Paso 3: Desplazamiento de las letras usando la clave
    palabra_encriptada = ""
    for i, letra in enumerate(palabra_invertida):
        if letra in conjunto_caracteres:
            desplazamiento = claves_numericas[i % len(claves_numericas)]
            nueva_pos = (conjunto_caracteres.index(letra) + desplazamiento) % len(conjunto_caracteres)
            letra_encriptada = conjunto_caracteres[nueva_pos]
            palabra_encriptada += letra_encriptada
        else:
            # Si no es un carácter conocido, lo mantenemos igual
            palabra_encriptada += letra
    
    return palabra_encriptada

# Función para desencriptar una palabra
def desencriptar_palabra_compleja(palabra_encriptada):
    # Paso 1: Crear una clave numérica basada en la clave secreta
    claves_numericas = [
        conjunto_caracteres.index(letra)
        for letra in CLAVE_SECRETA
        if letra in conjunto_caracteres
    ]
    
    # Paso 2: Desplazamiento negativo de las letras usando la clave
    palabra_desencriptada = ""
    for i, letra in enumerate(palabra_encriptada):
        if letra in conjunto_caracteres:
            desplazamiento = claves_numericas[i % len(claves_numericas)]
            nueva_pos = (conjunto_caracteres.index(letra) - desplazamiento) % len(conjunto_caracteres)
            letra_desencriptada = conjunto_caracteres[nueva_pos]
            palabra_desencriptada += letra_desencriptada
        else:
            # Si no es un carácter conocido, lo mantenemos igual
            palabra_desencriptada += letra
    
    return palabra_desencriptada[::-1]  # Invertimos para obtener la palabra original

# Función principal para interactuar con el usuario
def main():
    palabra_encriptada = None  # Inicializamos la variable para almacenar la palabra encriptada
    
    while True:
        # Mostrar opciones al usuario
        print("\nSeleccione una opción:")
        print("1. Encriptar una palabra")
        print("2. Desencriptar una palabra")
        print("3. Salir")
        
        # Leer la opción del usuario
        opcion = input("Elija 1, 2 o 3: ").strip()
        
        if opcion == "1":
            palabra = input("Ingrese la palabra a encriptar: ").strip()
            palabra_encriptada = encriptar_palabra_compleja(palabra)
            print("Palabra encriptada:", palabra_encriptada)
        elif opcion == "2":
            if palabra_encriptada is None:
                print("Primero debe encriptar una palabra antes de poder desencriptarla.")
            else:
                desencriptada = desencriptar_palabra_compleja(palabra_encriptada)
                print("Palabra desencriptada:", desencriptada)
        elif opcion == "3":
            print("Saliendo del programa.")
            break  # Salir del bucle y terminar el programa
        else:
            print("Opción no válida. Por favor, ingrese 1, 2 o 3.")

# Ejecutar la función principal
if __name__ == "__main__":
    main()
